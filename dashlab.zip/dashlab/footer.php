<footer id="footer">
         <div class="container-fluid">
            <div class="row-fluid">
               <div class="span5">
                  <h3>Contact Information</h3>
                  <p><b>Office Hours: </b>Monday-Friday (8.00am - 5.00pm)</p>
                  <p><b>Phone: </b>999-999-9999</p>
                  <p><b>Cell: </b>999-999-9999</p>
                  <a href="mailto:ooyeleke@stevens.edu">Email</a>
               </div>
               <div class="span2">
                  <a href="#"><img src = "images/DASH-FULL_white.png"  width="150px" alt="research-lab-logo"/></a>
               </div>
               <div class="span5">
                  <h3>Address</h3>
                  <p>DASH Research Laboratory<br>
                     North Building,
                     1, Castle Point Terrace,<br>
                     Hoboken, NJ<br>
                     USA 07030
                  </p>
                  <a href="https://goo.gl/maps/uATie6rknKkdk4RT8">Show Map</a>
               </div>
            </div>
         </div>
      </footer>