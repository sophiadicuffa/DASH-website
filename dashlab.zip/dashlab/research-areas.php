<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <title>Research Areas</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="description" content="Research Lab, Home, Stevens Institute of Technology">
      <meta name="author" content="">
      <!-- Le styles -->
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <link href="css/bootstrap-responsive.min.css" rel="stylesheet">
      <link href="css/theme.css" rel="stylesheet">
   </head>
   <body>
      <div class="container">
      <?php include ('header.php') ?>
      <?php include ('navbar.php') ?>
       <hr>
         <div class="row-fluid">
            <div class="span3 bs-docs-sidebar" id="navparent">

               <ul class="nav nav-list bs-docs-sidenav" data-spy="affix" data-offset-top="200" data-offset-bottom="260">
                  <li><a href="#research_areas"> Research Areas </a></li>
                  <li><a href="#gerontechnology"> Gerontechnology </a></li>
                  <li><a class="subhead" href="#healthcare"> Healthcare </a></li>
                  <li><a class="subhead" href="#disparities"> Disparities  </a></li>
                  <li><a class="subhead" href="#mhealth"> m-Health </a></li>
                  <li><a href="#safety_systems">Safety-critical Systems</a></li>
                  <li><a class="subhead" href="#smart_home"> Smart Home </a></li>
                  <li><a class="subhead" href="#software_engineering"> Software Engineering </a></li>
               </ul>
            </div>
            <div class="span8 offset1">
               <section id="research_areas">
                  <div class="page-header">
                     <h3>Research Areas</h3>
                     <hr>
                     <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas 
                        molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et 
                        dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil 
                        impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam 
                        et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum 
                        rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.
                     </p>
                  </div>
               </section>
               <section id="gerontechnology">
                  <div class="page-header">
                     <h3>Gerontechnology</h3>
                  </div>
                  <div class="row-fluid">
                     <div class="span12">
                        <section id="healthcare">
                           <h4>Healthcare</h4>
                           <br/>
                           <img src="images/scientist-with-petri-dish.jpg" class="float-right" alt="healthcare"/>
                           <p>
                              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
                              tempor incididunt ut labore et dolore magna aliqua. Et sollicitudin ac 
                              orci phasellus egestas tellus rutrum tellus pellentesque. Lectus mauris 
                              ultrices eros in cursus turpis. Egestas dui id ornare arcu odio ut. At 
                              augue eget arcu dictum varius duis at consectetur lorem. Dictum sit amet 
                              justo donec. Est ante in nibh mauris cursus mattis molestie. Ac feugiat 
                              sed lectus vestibulum mattis mhealth. Enim sit amet venenatis urna 
                              cursus eget nunc scelerisque viverra. Eget mauris pharetra et ultrices.
                           </p>
                         
                        </section>
                        <hr>
                        <section id="disparities">
                           <h4>Disparities</h4>
                           <br/>
                           <img src="images/brainstorming-paper.jpg" class="float-right" alt="Quam Id Leo"/>
                           <p>
                              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
                              tempor incididunt ut labore et dolore magna aliqua. Mollis aliquam ut 
                              porttitor leo. Sed faucibus turpis in eu mi bibendum neque. Ut tortor 
                              pretium viverra suspendisse. Posuere morbi leo urna molestie. Sed nisi 
                              lacus sed viverra tellus in hac habitasse. Diam maecenas sed enim ut sem. 
                              Congue nisi vitae suscipit tellus mauris a diam maecenas. Leo in vitae 
                              turpis massa sed. Turpis egestas integer eget aliquet nibh. Molestie 
                              nunc non blandit massa enim nec dui. Tempus iaculis urna id smart_home lacus.
                           </p>
                           
                        </section>
                        <hr>
                        <section id="mhealth">
                           <h4>m-Health</h4>
                           <br/>
                           <img src="images/man-with-microscope.jpg" class="float-right" alt="mhealth"/>
                           <p>
                              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do 
                              eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis 
                              hendrerit dolor magna eget est lorem ipsum dolor sit. Id ornare 
                              arcu odio ut. At lectus urna duis convallis convallis. Fermentum 
                              posuere urna nec tincidunt praesent semper. mhealth dignissim 
                              cras tincidunt lobortis feugiat vivamus. Eget lorem dolor sed 
                              viverra ipsum nunc aliquet bibendum. Enim lobortis scelerisque 
                              fermentum dui faucibus in ornare. Proin nibh nisl condimentum id 
                              venenatis a. Ipsum dolor sit amet consectetur adipiscing elit 
                              pellentesque.
                           </p>
                          
                        </section>
                     </div>
                  </div>
               </section>
               <hr>
               <section id="safety_systems">
                  <div class="page-header">
                     <h3>Safety-Critcal Systems</h3>
                  </div>
                  <div class="row-fluid">
                     <div class="span12">
                        <section id="smart_home">
                           <h4>Smart Home</h4>
                           <br/>
                           <img src="images/solar-2.jpg" class="float-right" alt="smart_home"/>
                           <p>
                              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor 
                              incididunt ut labore et dolore magna aliqua. Nisi quis eleifend quam adipiscing 
                              vitae proin. Metus vulputate eu scelerisque felis imperdiet proin fermentum. 
                              Consectetur adipiscing elit duis tristique sollicitudin. Faucibus ornare 
                              suspendisse sed nisi lacus sed viverra. Odio tempor orci dapibus ultrices in 
                              iaculis nunc sed augue. Laoreet non curabitur gravida arcu ac tortor dignissim 
                              convallis aenean. Posuere sollicitudin aliquam ultrices sagittis orci. Tellus 
                              orci ac auctor augue. Tristique risus nec feugiat in. In est ante in nibh mauris. 
                              Neque gravida in fermentum et sollicitudin ac. Commodo viverra maecenas accumsan 
                              lacus vel safety_systems smart_home. Aliquam malesuada bibendum arcu vitae elementum.
                           </p>
                        </section>
                        <hr>
                        <section id="software_engineering">
                           <h4>Software Engineering</h4>
                           <br/>
                           <img src="images/energy.jpg" class="float-right" alt="Elementum Tempus"/>
                           <p>
                              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor 
                              incididunt ut labore et dolore magna aliqua. Quisque sagittis purus sit amet 
                              smart_home consequat mauris nunc congue. Arcu ac tortor dignissim convallis aenean. 
                              Etiam non quam lacus suspendisse faucibus interdum posuere lorem ipsum. Lorem 
                              mollis aliquam ut porttitor leo a diam sollicitudin. Convallis aenean et tortor 
                              at risus viverra adipiscing at. Nibh cras pulvinar mattis nunc sed blandit libero. 
                              Venenatis a condimentum vitae sapien pellentesque. Diam maecenas ultricies mi eget 
                              mauris. safety_systems smart_home est velit egestas dui id. Ut ornare lectus sit amet est 
                              placerat in egestas erat. Vel elit scelerisque mauris pellentesque pulvinar 
                              pellentesque habitant.
                           </p>
                        
                        </section>
                       
                     </div>
                  </div>
               </section>
               <hr>
            </div>
         </div>
      </div>
      <?php include ('footer.php') ?>

      <!-- Le javascript
         ================================================== -->
      <!-- Placed at the end of the document so the pages load faster -->
      <script src="js/jquery-1.9.1.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script>
         $(document).ready(function() {
             $(document.body).scrollspy({
                 target: "#navparent"
             });
         });
         
      </script>
   </body>
</html>