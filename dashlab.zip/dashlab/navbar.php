<div class="masthead">
            <div class="navbar">
               <div class="navbar-inner">
                  <div class="container">
                  <button type="button" class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                     <span class="icon-bar"></span>
                  </button>
                  <div class="nav-collapse collapse">
                     <ul class="nav">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About</a></li>
                        <li class="dropdown">
                           <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                             Research
                             <b class="caret"></b>
                           </a>
                           <ul class="dropdown-menu" > 
                              <li style="display: inline;"><a href="research-areas.php#research_areas">Research Areas</a></li>
                              <li style="display: inline;"><a href="research-areas.php#gerontechnology">Gerontechnology</a></li>
                              <li style="display: inline;"><a href="research-areas.php#healthcare">Healthcare</a></li>
                              <li style="display: inline;"><a href="research-areas.php#disparities">Disparities</a></li>
                              <li style="display: inline;"><a href="research-areas.php#mhealth">m-Health</a></li>
                              <li style="display: inline;"><a href="research-areas.php#safety_systems">Safety-critical Systems</a></li>
                              <li style="display: inline;"><a href="research-areas.php#smart_home">Smart Home</a></li>
                              <li style="display: inline;"><a href="research-areas.php#software_engineering">Software Engineering</a></li>
                           </ul>
                         </li>
                         <li class="dropdown">
                           <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                             Projects
                             <b class="caret"></b>
                           </a>
                           <ul class="dropdown-menu" > 
                              <li style="display: inline;"><a href="ongoing-projects.php">Ongoing Projects</a></li>
                              <li style="display: inline;"><a href="publications.php">Publications</a></li>
                              <li style="display: inline;"><a href="collaborators.php">Collaborators</a></li>
                              <li style="display: inline;"><a href="achived-projects.php">Achived Projects</a></li>
                           </ul>
                         </li>

                        <li><a href="people.php">People</a></li>

                        <li class="dropdown">
                           <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                             Activities
                             <b class="caret"></b>
                           </a>
                           <ul class="dropdown-menu" > 
                              <li style="display: inline;"><a href="activities.php#Teaching">Teaching</a></li>
                              <li style="display: inline;"><a href="activities.php#Membership">Membership</a></li>
                              <li style="display: inline;"><a href="activities.php#Professional">Professional Service</a></li>
                              <li style="display: inline;"><a href="activities.php#Institutional">Institutional Service</a></li>
                           </ul>
                         </li>
                        <li><a href="news.php">News</a></li>
                        <li><a href="contact.php">Contact</a></li>
                     </ul> </div>
                  <!--/.nav-collapse -->
                  </div>
               </div>
            </div>
         </div>