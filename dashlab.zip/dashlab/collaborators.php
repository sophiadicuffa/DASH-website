<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <title>Collaborators</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="description" content="Research Lab, Home, Stevens Institute of Technology">
      <meta name="author" content="">
      <!-- Le styles -->
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <link href="css/bootstrap-responsive.min.css" rel="stylesheet">
      <link href="css/theme.css" rel="stylesheet">
   </head>
   <body>
      <div class="container">
      <?php include ('header.php') ?>
      <?php include ('navbar.php') ?>
        
         <hr>
         <div class="row-fluid">
            <div class="span3 bs-docs-sidebar" id="navparent">
               <ul class="nav nav-list bs-docs-sidenav" data-spy="affix" data-offset-top="200" data-offset-bottom="260">
               <li><a href="#collaborators">Collaborators</a></li>
               <li><a class="subhead" href="#jane">Jane Carmona</a></li>
               <li><a class="subhead" href="#ronny">Ronny Simon</a></li>
               <li><a class="subhead" href="#jenny">Jenny Lopez</a></li>
                  </ul>
            </div>
            <div class="span8 offset1">
               <section id="collaborators">
                  <div class="page-header">
                     <h3> Our Collaborators</h3>
                  </div>
                  <div class="row-fluid" id="jane">
                     <div class="span3">
                        <a href="https://unsplash.com/photos/aaaGLiTRqkg" class="thumbnail">
                        <img src="thumbs/jane-carmona.jpg" alt="Jane Carmona"/>
                        </a>
                     </div>
                     <div class="span9">
                        <h4><a href="https://unsplash.com/photos/aaaGLiTRqkg">Jane Carmona</a></h4>
                        <p>Jane received her B.E. in Mechanical Engineering from the Lorem Ipsum University of Lorem Ipsum in 2015 with High Honors. Her current research focuses on metus libero, eleifend sit amet pretium et, porta ac urna. Suspendisse ullamcorper mollis ligula et fermentum. .</p>
                        <p><b>Email: </b><a href="mailto:jane.email@uni.edu">jane.email@uni.edu</a></p>
                        <p><b>Address: </b>999 Fake Street Avenue, City, State Country ZIP</p>
                     </div>
                  </div>
                  <hr>
                  <div class="row-fluid" id="ronny">
                     <div class="span3">
                        <a href="https://unsplash.com/photos/LUdelQ2EO2g" class="thumbnail">
                        <img src="thumbs/ronny-sison.jpg" alt="Ronny Simon"/>
                        </a>
                     </div>
                     <div class="span9">
                        <h4><a href="https://unsplash.com/photos/LUdelQ2EO2g">Ronny Simon</a></h4>
                        <p>Ronny received his B.Tech in Electrical Engineering from the Lorem Ipsum Institute of Technology. His current research focuses on ullamcorper nibh ut orci eleifend varius elementum ut augue. Proin ornare, arcu et efficitur laoreet, purus ante dictum leo, vel pulvinar velit leo sed nunc. </p>
                        <p><b>Email: </b><a href="mailto:ronny.email@uni.edu">ronny.email@uni.edu</a></p>
                        <p><b>Address: </b>999 Fake Street Avenue, City, State Country ZIP</p>
                     </div>
                  </div>
                  <hr>
                  <div class="row-fluid" id="jenny">
                     <div class="span3">
                        <a href="https://unsplash.com/photos/nomivMNW07o" class="thumbnail">
                        <img src="thumbs/graduate-1.jpg" alt="Jenny Lopez"/>
                        </a>
                     </div>
                     <div class="span9">
                        <h4><a href="https://unsplash.com/photos/nomivMNW07o">Jenny Lopez</a></h4>
                        <p>Jenny received her B.S. degree in Mechanical Engineering from the Lorem Ipsum Technical University in 2012 with High Honors, where she focused on quis nisl vitae lectus pharetra dapibus. In sit amet erat purus. Proin finibus, nunc sed faucibus molestie, risus tellus sodales elit, nec luctus urna augue vitae dolor. Curabitur nisl eros, rhoncus eget mauris vitae.</p>
                        <p><b>Email: </b><a href="mailto:jenny.email@uni.edu">jenny.email@uni.edu</a></p>
                        <p><b>Address: </b>999 Fake Street Avenue, City, State Country ZIP</p>
                     </div>
                  </div>
                  <hr>
               </section>
               
            </div>
         </div>
      </div>
      <?php include ('footer.php') ?>
</div>
        

      <!-- Le javascript
         ================================================== -->
      <!-- Placed at the end of the document so the pages load faster -->
      <script src="js/jquery-1.9.1.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script>
         $(document).ready(function() {
             $(document.body).scrollspy({
                 target: "#navparent"
             });
         });
         
      </script>
   </body>
</html>