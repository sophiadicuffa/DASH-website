<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <title>About</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="description" content="Research Lab, Home, Stevens Institute of Technology">
      <meta name="author" content="">
      <!-- Le styles -->
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <link href="css/bootstrap-responsive.min.css" rel="stylesheet">
      <link href="css/theme.css" rel="stylesheet">
   </head>
   <body>
      <div class="container">
      <?php include ('header.php') ?>
      <?php include ('navbar.php') ?>
        
         <hr>
         <div class="row-fluid">
            <div class="span3 bs-docs-sidebar" id="navparent">
               <ul class="nav nav-list bs-docs-sidenav" data-spy="affix" data-offset-top="200" data-offset-bottom="260">
                  <li><a href="#statemet"> About </a></li>
                  <li><a href="#nano"> Enim Raesent Elementum </a></li>
                  <li><a class="subhead" href="#Penatibus"> Penatibus </a></li>
                  <li><a href="#Facilisis">Facilisis</a></li>
                  <li><a class="subhead" href="#FacilisisMagna"> Facilisis Magna </a></li>
               </ul>
            </div>
            <div class="span8 offset1">
               <section id="statemet">
                  <div class="page-header">
                     <h3>About DASH LAB</h3>
                     <hr>
                     <p>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas 
                        molestias excepturi sint occaecati cupiditate non provident, similique sunt in culpa qui officia deserunt mollitia animi, id est laborum et 
                        dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio. Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil 
                        impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam 
                        et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum 
                        rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.
                     </p>
                  </div>
               </section>
               <section id="nano">
                  <div class="page-header">
                     <h3>Enim Raesent Elementum</h3>
                  </div>
                  <div class="row-fluid">
                     <div class="span12">
                        <section id="Penatibus">
                           <h4>Penatibus</h4>
                           <br/>
                           <img src="images/scientist-with-petri-dish.jpg" class="float-right" alt="Penatibus"/>
                           <p>
                              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
                              tempor incididunt ut labore et dolore magna aliqua. Et sollicitudin ac 
                              orci phasellus egestas tellus rutrum tellus pellentesque. Lectus mauris 
                              ultrices eros in cursus turpis. Egestas dui id ornare arcu odio ut. At 
                              augue eget arcu dictum varius duis at consectetur lorem. Dictum sit amet 
                              justo donec. Est ante in nibh mauris cursus mattis molestie. Ac feugiat 
                              sed lectus vestibulum mattis ullamcorper. Enim sit amet venenatis urna 
                              cursus eget nunc scelerisque viverra. Eget mauris pharetra et ultrices.
                           </p>
                           <p>
                              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod 
                              tempor incididunt ut labore et dolore magna aliqua. Volutpat commodo sed 
                              egestas egestas fringilla phasellus faucibus scelerisque eleifend. Mi 
                              proin sed libero enim sed faucibus turpis in. Volutpat sed cras ornare 
                              arcu dui vivamus arcu felis bibendum. Non consectetur a erat nam at lectus 
                              urna. Risus feugiat in ante metus dictum at. Cras sed felis eget velit 
                              aliquet sagittis id. Turpis massa tincidunt dui ut ornare lectus sit amet. 
                              Lectus sit amet est placerat. Risus at ultrices mi tempus. 
                           </p>
                        </section>
                       
                     </div>
                  </div>
               </section>
               <hr>
               <section id="Facilisis">
                  <div class="page-header">
                     <h3>Facilisis</h3>
                  </div>
                  <div class="row-fluid">
                     <div class="span12">
                        <section id="FacilisisMagna">
                           <h4>Facilisis Magna</h4>
                           <br/>
                           <ol class="resources">
                              <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor 
                                 incididunt ut labore et dolore magna aliqua. p. 413-417, 2010.
                              </li>
                              <li>Sed ullamcorper morbi tincidunt ornare massa eget egestas. Suscipit tellus mauris 
                                 a diam. Facilisis magna etiam tempor orci eu lobortis elementum nibh tellus.  
                              </li>
                              <li>Tellus molestie nunc non blandit massa enim nec dui. Eget duis at tellus at urna 
                                 condimentum mattis pellentesque id. At urna condimentum mattis pellentesque id nibh 
                                 tortor. Placerat duis ultricies lacus sed turpis tincidunt id aliquet risus. 
                              </li>
                              <li>Laoreet non curabitur gravida arcu ac. Ultricies tristique nulla aliquet enim. Auctor 
                                 elit sed vulputate mi. Pellentesque diam volutpat commodo sed egestas egestas fringilla. 
                                 Eleifend donec pretium vulputate sapien nec sagittis. 38(5), p. 397-406, 2013.
                              </li>
                           </ol>
                        </section>
                     </div>
                  </div>
               </section>
               <hr>
            </div>
         </div>
      </div>
      <?php include ('footer.php') ?>
</div>
      <!-- Le javascript
         ================================================== -->
      <!-- Placed at the end of the document so the pages load faster -->
      <script src="js/jquery-1.9.1.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script>
         $(document).ready(function() {
             $(document.body).scrollspy({
                 target: "#navparent"
             });
         });
         
      </script>
   </body>
</html>