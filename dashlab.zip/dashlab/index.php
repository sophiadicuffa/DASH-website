<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <title>DASH Research Lab - Home</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="description" content="Research Lab, Home, Stevens Institute of Technology">
      <meta name="author" content="">
      <!-- Le styles -->
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <link href="css/bootstrap-responsive.min.css" rel="stylesheet">
      <link href="css/theme.css" rel="stylesheet">
   </head>
   <body>

      <div class="container">
        <?php include ('header.php') ?>

   <!-- <div class="box-padding-md grey-bg">
    <div class="jumbotron jumbotron-fluid">
      <div class="container">  
        <div class="media p-3">
          <img src="https://i.imgur.com/v9f1nS2.jpg" alt="John Doe" class="mr-3 mt-3 rounded-circle" style="width:60px;">
           <div class="media-body">
            <h3 class="display-5">"Espher Information Assocation"</h3>
            <p class="lead">제16세대 프로젝트</p>
          </div>
        </div>
      </div>
    </div>
  </div> -->
       <?php include('navbar.php') ?>

         <div class="row-fluid">
            <div class="span12">
               <div id="main-carousel" class="carousel slide">
                  <div class="carousel-inner">
                     <div class="item active">
                        <img src="images/stevens_view.png" class="carousel-image" alt="">                      
                        <div class="carousel-caption">
                           <h4>Welcome to the DASH Research Laboratory</h4>
                           <!-- -->
                           <p></p>
                        </div>
                     </div>
                     <div class="item">
                        <img src="images/stevens_environ.jpeg" class="carousel-image" alt="">
                        <div class="carousel-caption">
                           <h4>Lab Photos</h4>
                           <p></p>
                        </div>
                     </div>
                     <div class="item">
                        <img src="images/hoboken_0.jpeg" class="carousel-image" alt="">
                        <div class="carousel-caption">
                           <h4>Main Building Photo</h4>
                           <p></p>
                        </div>
                     </div>
                  </div>
                  <a class="left carousel-control" href="#main-carousel" data-slide="prev">‹</a>
                  <a class="right carousel-control" href="#main-carousel" data-slide="next">›</a>
               </div>
            </div>
         </div>
         <hr>
         <div class="container-fluid">
            <div class="row-fluid marketing">
               <div class="span12">
                  <p>
                     Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla faucibus non tortor nec congue. 
                     Donec dictum rhoncus urna eget gravida. Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
                     Vivamus id rutrum enim, quis malesuada dui. Sed ullamcorper sapien sed nunc hendrerit, sed dapibus 
                     ligula accumsan. 
                  </p>
                  <br/>
               </div>
               <div class="row-fluid">
                  <hr>
                  <h2 class="centered">Recent News</h2>
                  <hr>
               </div>
               <div class="span4 feature-item">
                  <h5> <span class="date"> May 1, 2019 </span> </h5>
                  <h4 class="feature-heading">
                     <a href="#">
                        Babafemi Joins DASH LAB for Fall 2021
                     </a>
                     <br/>
                  </h4>
                  <hr>
                  <div class="centered">
                     <a href="#">
                     <img src="images/res/babafemi.jpg" alt=""></a>
                  </div>
                  <hr>
                  <p>
                     Babafemi Sorinolu joins Stevens Institute of Technology to commence his PhD 
                     in Software Engineering. He has a Masters degree in 
                     Computer science from Nigeria's premier university, The university of ibadan.
                      <a href="news.php">here</a>.
                  </p>
                  <br/>
                  <br/>
               </div>
               <!-- <div class="span4 feature-item">
                  <h5> <span class="date">April 20, 2019</span> </h5>
                  <h4 class="feature-heading">
                     <a href="https://unsplash.com/photos/rTZW4f02zY8">
                     Tincidunt tortor aliquam nulla facilisi. Nunc scelerisque viverra mauris in
                     </a>
                  </h4>
                  <hr>
                  <div class="centered">
                     <a href="https://unsplash.com/photos/rTZW4f02zY8">
                     <img src="thumbs/nasa-89125-unsplash.jpg" alt="">
                     </a>
                  </div>
                  <hr>
                  <p>
                     Read the paper 
                     <a href="https://unsplash.com/photos/rTZW4f02zY8">here</a>.
                     Consequat semper viverra nam libero justo laoreet. Commodo odio aenean sed adipiscing diam donec. 
                  </p>
                  <br/>
               </div> -->
               <!-- <div class="row-fluid">
                  <div class="span4 feature-item">
                     <h5> <span class="date">October 2, 2018</span> </h5>
                     <h4 class="feature-heading">
                        <a href="http://mechanical.illinois.edu/news/miljkovic-pleased-join-%E2%80%98powerhouse%E2%80%99-illinois">
                        Pretium lectus quam id leo in vitae turpis massa
                        <br/>
                        <br/>
                        </a>
                     </h4>
                     <hr>
                     <div class="centered">
                        <a href="https://unsplash.com/photos/WNk-f-TnZDw">
                        <img src="thumbs/rodolfo-cuadros-762364-unsplash.jpg" alt=""></a>
                     </div>
                     <hr>
                     <p> 
                        Tristique senectus et netus et malesuada. Sed viverra tellus in hac habitasse platea dictumst vestibulum rhoncus. 
                        Read it <a href="https://unsplash.com/photos/WNk-f-TnZDw">here</a>.
                     </p>
                     <br/>					
                  </div>
               </div>
               <hr>
            </div>
            <div class="row-fluid">
               <div class="span4 feature-item">
                  <h4 class="feature-heading"><a href="https://unsplash.com/photos/QvbLjB9pHLM">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut sit amet ultrices velit habitasse platea</a></h4>
                  <hr>
                  <div class="centered">
                     <a href="https://unsplash.com/photos/QvbLjB9pHLM"><img src="thumbs/ivanov-crop.JPG" alt=""></a>
                  </div>
                  <hr>
                  <p>Aecenas consectetur vestibulum orci ut vulputate. Aenean cursus finibus pulvinar <a href="https://unsplash.com/photos/QvbLjB9pHLM">here</a>. </p>
                  <br/>
               </div>
               <div class="span4 feature-item">
                  <h4 class="feature-heading"><a href="https://unsplash.com/photos/lQGJCMY5qcM">Maecenas placerat ullamcorper eros a vehicula. Duis mollis tortor ut elit elementum</a></h4>
                  <hr>
                  <div class="centered">
                     <a href="https://unsplash.com/photos/lQGJCMY5qcM"><img src="thumbs/beaker-crop.JPG" alt=""></a>
                  </div>
                  <hr>
                  <p>Read the paper <a href="https://unsplash.com/photos/lQGJCMY5qcM">here</a> </p>
               </div>
               <div class="span4 feature-item">
                  <h4 class="feature-heading"><a href="https://unsplash.com/photos/QCbZ4ASLhM8">Fusce tempor placerat felis, et placerat sapien lacinia sit amet<br/><br/><br/></a></h4>
                  <hr>
                  <div class="centered">
                     <a href="https://unsplash.com/photos/QCbZ4ASLhM8"><img src="thumbs/sato-chart.JPG" alt=""></a>
                  </div>
                  <hr>
                  <p> Aenean posuere, nulla ut placerat fringilla, dolor dolor pellentesque metus. Read the paper <a href="https://unsplash.com/photos/QCbZ4ASLhM8">here</a>.</p>
                  <br/>
                  <br/>
                  <br/>
               </div>
            </div> -->
         </div>
      </div>
    <?php include('footer.php') ?>
</div> <!--  Container div  -->
      <!-- Javascript files -->
      <script src="js/jquery-1.9.1.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script> $('#main-carousel').carousel(); </script>
   </body>
</html>