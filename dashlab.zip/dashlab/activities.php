<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="utf-8">
   <title>Activities</title>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <meta name="description" content="Research Lab, Home, Stevens Institute of Technology">
   <meta name="author" content="">
   <!-- Le styles -->
   <link href="css/bootstrap.min.css" rel="stylesheet">
   <link href="css/bootstrap-responsive.min.css" rel="stylesheet">
   <link href="css/theme.css" rel="stylesheet">
</head>

<body>
   <div class="container">
      <?php include ('header.php') ?>
      <?php include ('navbar.php') ?>

      <hr>
      <div class="row-fluid">
         <div class="span3 bs-docs-sidebar" id="navparent">
            <ul class="nav nav-list bs-docs-sidenav" data-spy="affix" data-offset-top="200" data-offset-bottom="260">
               <li><a href="#Teaching"> Teaching </a></li>
               <li><a class="subhead" href="#ke142"> KE 142: Tortor Vitae Purus</a></li>
               <li><a class="subhead" href="#ke121"> KE 121: Ullamcorper Malesuada</a></li>
               <li><a href="#Membership"> Membership </a></li>
               <li><a href="#Professional"> Professional Services </a></li>
               <li><a href="#Institutional"> Institutional Services </a></li>

            </ul>
         </div>

         <div class="span8 offset1">

            <section id="Teaching">
               <div class="page-header">
                  <h3>Teaching</h3>
               </div>
               <div class="row-fluid">
                  <div class="span12">

                     <section id="ke142">
                        <div class="page-header">
                           <h5><a href="">KE 142: Tortor Vitae Purus</a></h5>
                           <hr>
                           <p>Quam viverra orci sagittis eu volutpat odio. Ultricies tristique nulla aliquet enim tortor
                              at auctor urna nunc. </p>
                           <p><b>Prerequisite: </b><a href=""><b>ME 310</b></a> and <a href=""><b>ME 320</b></a>.</p>
                           <p><b>Semesters Taught:</b> Fall 2018.</p>
                           <!-- <p><b>Course Information:</b> <a href="">Syllabus</a></p>
                     <table class="table table-striped">
                        <thead>
                           <tr>
                              <th>#</th>
                              <th>Lecture</th>
                        </thead>
                        <tbody>
                           <tr>
                              <td>1</td>
                              <td><a href="">Pretium Lectus Quam</a></td>
                           </tr>
                           <tr>
                              <td>2</td>
                              <td><a href="">Urna porttitor: Rhoncus dolor purus non enim praesent elementum facilisis.</a></td>
                           </tr>
                           <tr>
                              <td>3</td>
                              <td><a href="">Diam in arcu: Cursus euismod quis viverra nibh cras.</a></td>
                           </tr>
                           <tr>
                              <td>4</td>
                              <td><a href="">Tristique: Sollicitudin nibh sit amet commodo. </a></td>
                           </tr>
                           <tr>
                              <td>5</td>
                              <td><a href="">Risus: Viverra adipiscing at in tellus integer. </a></td>
                           </tr>
                           <tr>
                              <td>6</td>
                              <td><a href="">Mus mauris vitae ultricies leo.</a></td>
                           </tr>
                           <tr>
                              <td>7</td>
                              <td><a href="">Sed faucibus turpis in eu mi bibendum neque egestas. </a></td>
                           </tr>
                           <tr>
                              <td>8</td>
                              <td><a href="">Viverra aliquet eget sit amet tellus.</a></td>
                           </tr>
                        </tbody>
                     </table> -->
                        </div>
                     </section>
                     <section id="ke121">
                        <div class="page-header">
                           <h5><a href="">KE 121: Ullamcorper Malesuada</a></h5>
                           <hr>
                           <p>Morbi enim nunc faucibus a pellentesque sit amet porttitor eget. Aliquet bibendum enim
                              facilisis gravida. </p>
                           <p><b>Prerequisite:</b> Mus mauris vitae.</p>
                           <p><b>Semesters Taught:</b> Fall 2018.</p>
                        </div>
                     </section>

                  </div>
               </div>
            </section>

            <section id="Membership">
            <div class="page-header">
                  <h3>Membership</h3>
               </div>
               <!-- <h4>Membership</h4>
               <br /> -->
               <ol class="resources">
                  <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                     incididunt ut labore et dolore magna aliqua. p. 413-417, 2010.
                  </li>
                  <li>Sed ullamcorper morbi tincidunt ornare massa eget egestas. Suscipit tellus mauris
                     a diam. Facilisis magna etiam tempor orci eu lobortis elementum nibh tellus.
                  </li>
                  <li>Tellus molestie nunc non blandit massa enim nec dui. Eget duis at tellus at urna
                     condimentum mattis pellentesque id. At urna condimentum mattis pellentesque id nibh
                     tortor. Placerat duis ultricies lacus sed turpis tincidunt id aliquet risus.
                  </li>
                  <li>Laoreet non curabitur gravida arcu ac. Ultricies tristique nulla aliquet enim. Auctor
                     elit sed vulputate mi. Pellentesque diam volutpat commodo sed egestas egestas fringilla.
                     Eleifend donec pretium vulputate sapien nec sagittis. 38(5), p. 397-406, 2013.
                  </li>
               </ol>
            </section>

            <hr>
            <section id="Professional">
            <div class="page-header">
                  <h3>Professional Services</h3>
               </div>
              
               <ol class="resources">
                  <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                     incididunt ut labore et dolore magna aliqua. p. 413-417, 2010.
                  </li>
                  <li>Sed ullamcorper morbi tincidunt ornare massa eget egestas. Suscipit tellus mauris
                     a diam. Facilisis magna etiam tempor orci eu lobortis elementum nibh tellus.
                  </li>
                  <li>Tellus molestie nunc non blandit massa enim nec dui. Eget duis at tellus at urna
                     condimentum mattis pellentesque id. At urna condimentum mattis pellentesque id nibh
                     tortor. Placerat duis ultricies lacus sed turpis tincidunt id aliquet risus.
                  </li>
                  <li>Laoreet non curabitur gravida arcu ac. Ultricies tristique nulla aliquet enim. Auctor
                     elit sed vulputate mi. Pellentesque diam volutpat commodo sed egestas egestas fringilla.
                     Eleifend donec pretium vulputate sapien nec sagittis. 38(5), p. 397-406, 2013.
                  </li>
                  <li>Laoreet non curabitur gravida arcu ac. Ultricies tristique nulla aliquet enim. Auctor
                     elit sed vulputate mi. Pellentesque diam volutpat commodo sed egestas egestas fringilla.
                     Eleifend donec pretium vulputate sapien nec sagittis. 38(5), p. 397-406, 2013.
                  </li>
                  <li>Laoreet non curabitur gravida arcu ac. Ultricies tristique nulla aliquet enim. Auctor
                     elit sed vulputate mi. Pellentesque diam volutpat commodo sed egestas egestas fringilla.
                     Eleifend donec pretium vulputate sapien nec sagittis. 38(5), p. 397-406, 2013.
                  </li>
                  <li>Laoreet non curabitur gravida arcu ac. Ultricies tristique nulla aliquet enim. Auctor
                     elit sed vulputate mi. Pellentesque diam volutpat commodo sed egestas egestas fringilla.
                     Eleifend donec pretium vulputate sapien nec sagittis. 38(5), p. 397-406, 2013.
                  </li>
                  <li>Laoreet non curabitur gravida arcu ac. Ultricies tristique nulla aliquet enim. Auctor
                     elit sed vulputate mi. Pellentesque diam volutpat commodo sed egestas egestas fringilla.
                     Eleifend donec pretium vulputate sapien nec sagittis. 38(5), p. 397-406, 2013.
                  </li>
               </ol>
            </section>

            <hr>
            <section id="Institutional">
            <div class="page-header">
                  <h3>Institutional Services</h3>
               </div>
               <ol class="resources">
                  <li>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                     incididunt ut labore et dolore magna aliqua. p. 413-417, 2010.
                  </li>
                  <li>Sed ullamcorper morbi tincidunt ornare massa eget egestas. Suscipit tellus mauris
                     a diam. Facilisis magna etiam tempor orci eu lobortis elementum nibh tellus.
                  </li>
                  <li>Tellus molestie nunc non blandit massa enim nec dui. Eget duis at tellus at urna
                     condimentum mattis pellentesque id. At urna condimentum mattis pellentesque id nibh
                     tortor. Placerat duis ultricies lacus sed turpis tincidunt id aliquet risus.
                  </li>
                  <li>Laoreet non curabitur gravida arcu ac. Ultricies tristique nulla aliquet enim. Auctor
                     elit sed vulputate mi. Pellentesque diam volutpat commodo sed egestas egestas fringilla.
                     Eleifend donec pretium vulputate sapien nec sagittis. 38(5), p. 397-406, 2013.
                  </li>
               </ol>
            </section>



         </div>
      </div>
   </div>
   <?php include ('footer.php') ?>
   </div>
   <!-- Le javascript
         ================================================== -->
   <!-- Placed at the end of the document so the pages load faster -->
   <script src="js/jquery-1.9.1.min.js"></script>
   <script src="js/bootstrap.min.js"></script>
   <script>
      $(document).ready(function () {
         $(document.body).scrollspy({
            target: "#navparent"
         });
      });

   </script>
</body>

</html>