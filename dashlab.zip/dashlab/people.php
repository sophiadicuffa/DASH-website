<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <title>People</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <meta name="description" content="Research Lab, Home, Stevens Institute of Technology">
      <meta name="author" content="">
      <!-- Le styles -->
      <link href="css/bootstrap.min.css" rel="stylesheet">
      <link href="css/bootstrap-responsive.min.css" rel="stylesheet">
      <link href="css/theme.css" rel="stylesheet">
   </head>
   <body>
      <div class="container">
      <?php include ('header.php') ?>
      <?php include ('navbar.php') ?>
        
         <hr>
         <div class="row-fluid">
            <div class="span3 bs-docs-sidebar" id="navparent">
               <ul class="nav nav-list bs-docs-sidenav" data-spy="affix" data-offset-top="200" data-offset-bottom="260">
                  <li><a href="#principalinvestigator"> Principal Investigator </a></li>
                  <li><a href="#graduate">Graduate Students</a></li>
                  <li><a href="#undergraduate">Undergraduate Students</a></li>
               </ul>
            </div>
            <div class="span8 offset1">
               <section id="principalinvestigator">
                  <div class="page-header">
                     <h3>Principal Investigator/Lead Researcher</h3>
                  </div>
                  <div class="row-fluid">
                     <div class="span3">
                        <a href="https://unsplash.com/photos/aCZ2hiC-iDk" class="thumbnail">
                        <img src="thumbs/prof-photo2.jpg" alt="Joe Smith"/>
                        </a>
                     </div>
                     <div class="span9">
                        <h4>John Doe</h4>
                        <p>Assistant Professor of School of Systems and Engineering</p>
                        <p>Ph.D. in Mechanical Engineering, Lorem Ipsum, 2013<br/>M.S. in Mechanical Engineering, HRV, 2011<br/>BASc in Engineering, University of Lorem Ipsum, 2009</p>
                        <p><b>Phone: </b>(999) 999-9999 </p>
                        <p><b>Email: </b><a href="mailto:demo@stevens.edu">demo@stevens.edu</a></p>
                        <p><b>Address: </b>999 Fake Street Avenue, City, State Country ZIP</p>
                        <p><b><a href="https://www.myperfectcv.co.uk/cv-examples/chemistry-lab-technician-cv-sample">CV</a>, <a href="https://scholar.google.com/citations?user=EOveYbUAAAAJ&hl=en">Google Scholar</a>, <a href="https://www.linkedin.com">Linkedin</a>, <a href="https://www.researchgate.net/profile/Richie-O-Oyeleke">ResearchGate</a></b></p>
                     </div>
                  </div>
               </section>
               <hr>
               <section id="graduate">
                  <div class="page-header">
                     <h3>Graduate Students</h3>
                  </div>
                  <div class="row-fluid">
                     <div class="span3">
                        <a href="#" class="thumbnail">
                        <img src="images/res/babafemi.jpg" alt="Babafemi Sorinolu"/>
                        </a>
                     </div>
                     <div class="span9">
                        <h4><a href="#">Babafemi Sorinolu</a></h4>
                        <p>Babafemi received his Bachelors and Masters degree in Computer Science from the Bowen University (2015) and University of Ibadan (2019) respectively with High Honors. Her current research focuses on gerontechnology, and digital health.</p>
                        <p><b>Email: </b><a href="mailto:bsorinol@stevens.edu">bsorinol@stevens.edu</a></p>
                        <p><b>Address: </b>C2 Babbio 509, Stevens Institute of Technology NJ, USA 07307</p>
                     </div>
                  </div>
                 
                  
                  <!-- <div class="row-fluid">
                     <div class="span3">
                        <a href="https://unsplash.com/photos/LUdelQ2EO2g" class="thumbnail">
                        <img src="thumbs/ronny-sison.jpg" alt="Ronny Simon"/>
                        </a>
                     </div>
                     <div class="span9">
                        <h4><a href="https://unsplash.com/photos/LUdelQ2EO2g">Ronny Simon</a></h4>
                        <p>Ronny received his B.Tech in Electrical Engineering from the Lorem Ipsum Institute of Technology. His current research focuses on ullamcorper nibh ut orci eleifend varius elementum ut augue. Proin ornare, arcu et efficitur laoreet, purus ante dictum leo, vel pulvinar velit leo sed nunc. </p>
                        <p><b>Email: </b><a href="mailto:ronny.email@uni.edu">ronny.email@uni.edu</a></p>
                        <p><b>Address: </b>999 Fake Street Avenue, City, State Country ZIP</p>
                     </div>
                  </div>
                  <hr>
                  <div class="row-fluid">
                     <div class="span3">
                        <a href="https://unsplash.com/photos/nomivMNW07o" class="thumbnail">
                        <img src="thumbs/graduate-1.jpg" alt="Jenny Lopez"/>
                        </a>
                     </div>
                     <div class="span9">
                        <h4><a href="https://unsplash.com/photos/nomivMNW07o">Jenny Lopez</a></h4>
                        <p>Jenny received her B.S. degree in Mechanical Engineering from the Lorem Ipsum Technical University in 2012 with High Honors, where she focused on quis nisl vitae lectus pharetra dapibus. In sit amet erat purus. Proin finibus, nunc sed faucibus molestie, risus tellus sodales elit, nec luctus urna augue vitae dolor. Curabitur nisl eros, rhoncus eget mauris vitae.</p>
                        <p><b>Email: </b><a href="mailto:jenny.email@uni.edu">jenny.email@uni.edu</a></p>
                        <p><b>Address: </b>999 Fake Street Avenue, City, State Country ZIP</p>
                     </div>
                  </div>
                  <hr> -->
               </section>
               <hr>
               <section id="undergraduate">
                  <div class="page-header">
                     <h3>Undergraduate Students</h3>
                  </div>
                  <div class="row-fluid">
                     <div class="span3">
                        <a href="https://unsplash.com/photos/unr5ZqXXvqU" class="thumbnail">
                        <img src="thumbs/undergrad-1.jpg" alt="Hall Stevenson"/>
                        </a>
                     </div>
                     <div class="span9">
                        <h4>Hall Stevenson</h4>
                        <p>Hall is currently a second year undergraduate student in the Electrical Science and Engineering Department at VAS University. He is studying the bibendum consectetur metus. Vivamus ullamcorper nibh ut orci eleifend varius elementum ut augue.</p>
                     </div>
                  </div>
                  <!--
                  <hr>
                  <div class="row-fluid">
                     <div class="span3">
                        <a href="https://unsplash.com/photos/GIy2ly37Kw8" class="thumbnail">
                        <img src="thumbs/graduate-2.jpg" alt="Simon Singh"/>
                        </a>
                     </div>
                     <div class="span9">
                        <h4>Simon Singh</h4>
                        <p>Simon is currently a second year undergraduate student in the Lorem Ipsum and Engineering Department at VAS University. He is working on rhoncus euismod tortor, ac lobortis tortor vestibulum sed. Ut in aliquam sapien. </p>
                     </div>
                  </div>
                  <hr>
                  <div class="row-fluid">
                     <div class="span3">
                        <a href="https://unsplash.com/photos/dju4--IW7Qw" class="thumbnail">
                        <img src="thumbs/graduate-3.jpg" alt="Tim Johnson"/>
                        </a>
                     </div>
                     <div class="span9">
                        <h4>Tim Johnson</h4>
                        <p>Tim is currently a second year undergraduate student in the Engineering Science Department at VAS University. He is currently studying sodales elit nec luctus urna augue vitae dolor. </p>
                     </div>
                  </div>
                  <hr>
                  <div class="row-fluid">
                     <div class="span3">
                        <a href="https://unsplash.com/photos/lEMHg4RFTW8" class="thumbnail">
                        <img src="thumbs/graduate-4.jpg" alt="Simona Alexander"/>
                        </a>
                     </div>
                     <div class="span9">
                        <h4>Simona Alexander</h4>
                        <p>Simona is currently a senior in the Lorem Ipsum Department at VAS. She is studying rhoncus eget mauris vitae, malesuada suscipit neque. Ut congue imperdiet lobortis. </p>
                     </div>
                  </div>
                  <hr>
                  <div class="row-fluid">
                     <div class="span3">
                        <a href="https://unsplash.com/photos/Nyt7CeiNXQw" class="thumbnail">
                        <img src="thumbs/graduate-5.jpg" alt="Zahima Sari"/>
                        </a>
                     </div>
                     <div class="span9">
                        <h4>Zahima Sari</h4>
                        <p>Zahima is currently a third year undergraduate student in the Lorem Ipsum Engineering Department at VAS. She is modling the dynamics tincidunt, odio non suscipit condimentum, neque diam viverra risus, vel tincidunt elit massa eu nulla. </p>
                     </div>
                  </div>
                  <hr>
                  <div class="row-fluid">
                     <div class="span3">
                        <a href="https://unsplash.com/photos/fNZfMhyd8Hs" class="thumbnail">
                        <img src="thumbs/graduate-6.jpg" alt="Alissa Zhi"/>
                        </a>
                     </div>
                     <div class="span9">
                        <h4>Alissa Zhi</h4>
                        <p>Alissa is currently a first year undergraduate student in the Science and Engineering Department at VAS. She is studying techniques to improve tempus pellentesque ex, et sollicitudin nunc faucibus vel. Suspendisse condimentum feugiat arcu, vitae pretium enim tempus eget.</p>
                     </div>
                  </div>
                  <hr>
                  <div class="row-fluid">
                     <div class="span3">
                        <a href="https://unsplash.com/photos/WC7KIHo13Fc" class="thumbnail">
                        <img src="thumbs/graduate-7.jpg" alt="David Tohm"/>
                        </a>
                     </div>
                     <div class="span9">
                        <h4>David Tohm</h4>
                        <p>David is currently a third year undergraduate student in the Science and Engineering Department at VAS. He is studying dui diam, pellentesque vel ullamcorper non, dictum eu tellus.</p>
                     </div>
                  </div>
                  <hr>
                  <div class="row-fluid">
                     <div class="span3">
                        <a href="https://unsplash.com/photos/APmln0DMSac" class="thumbnail">
                        <img src="thumbs/graduate-8.jpg" alt="Jessica Smith"/>
                        </a>
                     </div>
                     <div class="span9">
                        <h4>Jessica Smith</h4>
                        <p>Jessica is currently a second year undergraduate student in the Mechanical Engineering Department at VAS. She is studying Fusce et ullamcorper sapien. Integer tristique magna sed tellus faucibus imperdiet facilisis et quam.</p>
                     </div>
                  </div> -->
               </section>
            </div>
         </div>
      </div>
      <?php include ('footer.php') ?>
</div>

      <!-- Le javascript
         ================================================== -->
      <!-- Placed at the end of the document so the pages load faster -->
      <script src="js/jquery-1.9.1.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
      <script>
         $(document).ready(function() {
             $(document.body).scrollspy({
                 target: "#navparent"
             });
         });
         
      </script>
   </body>
</html>