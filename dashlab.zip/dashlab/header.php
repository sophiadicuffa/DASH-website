<header class="jumbotron subhead" id="overview">
            <!-- <p class="lead"> Stevens Institute of Technology </p> --> 
            <!--<img src="images/stevens_white.png"  style="border-right:1px solid #fff; margin-right:10px;" width="30%"/>-->
            <!--<img src="images/dash_head.png" style=" display: inline;" width="50%" />-->
            
            <img src="images/stevens_white.png"  style="border-right:1px solid #fff;" width="30%"/>
            <img src="images/dash_head.png" style=" display: inline;" width="65%" />
           
          
         </header>